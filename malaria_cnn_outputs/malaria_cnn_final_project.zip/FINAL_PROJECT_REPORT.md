# Malaria Cell Classification Using a CNN

**Project type:** Binary image classification  
**Generated:** 2026-10-17  
**Framework:** TensorFlow / Keras

## 1. Abstract

This project trains a convolutional neural network (CNN) to classify
microscopic cell images into two categories: Parasitized and Uninfected.
The model was trained using a training set, monitored on a validation
set, and evaluated on a held-out test set.

The recorded test accuracy is 96.15%, with a ROC-AUC of 0.9904.
These results are promising for this dataset, but do not establish
clinical readiness or performance on independent clinical populations.

## 2. Dataset and preprocessing

- Classes: Parasitized and Uninfected
- Recorded test set: 4,134 images (2,067 per class)
- Image size: 128 × 128 pixels
- Color format: RGB
- Pixel normalization: divide by 255
- Split proportions: 70% training, 15% validation, 15% test
- Random seed: 42

The dataset manifests and preprocessing configuration are retained
in the project outputs.

## 3. Model and training

The baseline is a custom sequential CNN with convolutional layers,
max-pooling, global average pooling, a dense layer with L2
regularization, dropout, and a sigmoid output.

Training used Adam and binary cross-entropy. Model checkpointing
selected the weights with the lowest validation loss. Early stopping
and learning-rate reduction callbacks were used.

Best epoch recorded: 13  
Best validation accuracy recorded: 96.25%  
Best validation loss recorded: 0.1099

## 4. Held-out test results

| Metric | Result |
|---|---:|
| Accuracy | 96.15% |
| Precision | 96.31% |
| Recall | 95.98% |
| F1-score | 96.15% |
| ROC-AUC | 0.9904 |

Precision and recall are useful complements to accuracy because they
describe different kinds of classification errors. The confusion
matrix and misclassified examples should be reviewed alongside these
summary metrics.

## 5. Error analysis

The recorded evaluation identified 159 misclassified test images.
The saved predictions file can be used to inspect false positives,
false negatives, and high-confidence errors.

Potential causes include visually ambiguous samples, image artifacts,
label noise, and differences between samples. These are hypotheses,
not confirmed explanations.

## 6. Limitations and validity

1. Duplicate or near-duplicate images across data splits have not
   been independently ruled out by this report.
2. If source-slide or patient identifiers are available, group-based
   splitting should be considered to assess generalization.
3. A balanced test set does not represent every real-world prevalence.
4. Model confidence is not necessarily a calibrated probability.
5. This model is an educational research prototype, not a validated
   medical diagnostic tool.

## 7. Further experiments

The following are proposed extensions and must not be described as
completed until their results are generated:

- Grad-CAM visual explanations
- Handcrafted color/texture features with Random Forest or SVM
- Transfer learning with MobileNetV2
- Augmentation ablation study
- Duplicate-image and split-integrity audit

For a fair comparison, preserve the same data partitions and use
validation data for model selection. Keep the test set untouched until
the final evaluation of each experiment.

## 8. Reproducibility

Included artifacts may contain the trained Keras model, train,
validation and test manifests, preprocessing configuration, training
history, test predictions, plots and metrics.

Re-run the notebook from the beginning in a fresh environment to
verify reproducibility before presenting the project as fully
reproducible.

## 9. Conclusion

The baseline CNN achieved 96.15% test accuracy and a
ROC-AUC of 0.9904 on the recorded test set. The next priority
is to validate split independence and compare the baseline against
alternative approaches. The results are promising within this
experimental setup, with further testing required before broader
generalization claims.
